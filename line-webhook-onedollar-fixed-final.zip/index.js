// Updated logic goes here
console.log('LINE bot ready');