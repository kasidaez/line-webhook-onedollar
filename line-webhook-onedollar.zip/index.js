
const express = require('express');
const line = require('@line/bot-sdk');
const crypto = require('crypto');
const handleEvent = require('./handleEvent');

const app = express();
const port = process.env.PORT || 10000;

const config = {
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET
};

// เก็บ rawBody
app.use(express.json({
  verify: (req, res, buf) => {
    req.rawBody = buf;
  }
}));

// Middleware ตรวจสอบ signature
app.post('/webhook', (req, res) => {
  const signature = req.headers['x-line-signature'];

  const isValid = line.validateSignature(
    req.rawBody,
    config.channelSecret,
    signature
  );

  if (!isValid) {
    console.log('❌ Signature validation failed');
    return res.status(401).send('Invalid signature');
  }

  const events = req.body.events;

  Promise
    .all(events.map(handleEvent))
    .then((result) => res.json(result))
    .catch((err) => {
      console.error(err);
      res.status(500).end();
    });
});

const client = new line.Client(config);

app.listen(port, () => {
  console.log(`✅ Your service is live on port ${port}`);
});
