
module.exports = async function handleEvent(event) {
  return { type: 'text', text: 'ระบบพร้อมใช้งานครับ' };
};
