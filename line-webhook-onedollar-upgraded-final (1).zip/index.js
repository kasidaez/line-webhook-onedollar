const express = require('express');
const line = require('@line/bot-sdk');
const app = express();

const config = {
  channelAccessToken: process.env.CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.CHANNEL_SECRET,
};

const client = new line.Client(config);

app.post('/webhook', line.middleware(config), (req, res) => {
  Promise.all(req.body.events.map(handleEvent)).then(result => res.json(result));
});

function handleEvent(event) {
  if (event.type !== 'message' || event.message.type !== 'text') {
    return Promise.resolve(null);
  }

  const msg = event.message.text.toLowerCase().trim();
  const now = new Date();
  const hour = now.getHours();
  const isNight = hour >= 21 || hour < 7;

  const isPhone = /^0[689]\d{8}$/.test(msg.replace(/[^0-9]/g, ''));

  let reply = '';

  if (msg.includes('เงินไม่เข้า')) {
    reply = `หากเงินยังไม่เข้าภายใน 3–5 นาที แนะนำให้ทักแอดมินที่ลิงก์นี้ได้เลยนะคะ 💬\n👉 https://lin.ee/INWaq47`;
  } else if (msg.includes('ถอน') && msg.includes('ไม่เข้า')) {
    reply = `ถ้าถอนเงินแล้วยังไม่เข้า อาจใช้เวลา 3–5 นาทีค่ะ\nถ้าเกินกว่านั้น ทักแอดมินให้ช่วยตรวจสอบได้นะคะ 💬\n👉 https://lin.ee/INWaq47`;
  } else if (msg.includes('ลืมรหัส') || msg.includes('รีเซ็ต')) {
    reply = `ถ้าลืมรหัสผ่าน แอดมินยินดีช่วยรีเซ็ตให้นะคะ\nรบกวนส่งข้อมูลต่อไปนี้มาได้เลยค่ะ 👇\n\n• ชื่อที่ใช้สมัคร\n• เบอร์โทร\n• ธนาคาร\n• เลขบัญชี`;
  } else if (msg.includes('เท่าไหร่') || msg.includes('ขั้นต่ำ')) {
    reply = '✅ ไม่มีขั้นต่ำเลยค่ะ จะฝาก–ถอนเท่าไหร่ก็ได้เลยนะคะ 😍';
  } else if (msg.includes('โปร') || msg.includes('โปรโมชั่น')) {
    reply = '🎉 ตอนนี้มีโปรดี ๆ เพียบเลยค่า\nสอบถามเพิ่มเติมหรือรับโปรที่นี่ได้เลย 👉 https://lin.ee/INWaq47';
  } else if (
    msg.includes('สมัคร') ||
    msg.includes('ลิงก์สมัคร') ||
    msg.includes('ขอสมัคร') ||
    msg.includes('สมัครให้หน่อย')
  ) {
    reply =
`📌 หากคุณยังไม่ได้เป็นสมาชิก  
สามารถสมัครได้ทันทีผ่านลิงก์นี้เลยค่ะ 👇  
🔗 https://play.onedollar.bet/signup?ref=xtcqTA

✅ ระบบสมัครง่าย ไม่ถึง 1 นาที พร้อมเริ่มเล่นได้ทันที  
รองรับทุกธนาคาร + ทรูวอเล็ต

หากคุณสะดวกให้แอดมินช่วยสมัครให้  
กรุณาพิมพ์ข้อมูลดังต่อไปนี้:

• ชื่อเล่น  
• ธนาคารที่ใช้  
• เลขบัญชี / เบอร์ทรูวอเล็ต

📍 แนะนำสมัครเองจะรวดเร็วกว่า รอไม่ถึงนาทีค่ะ  
มั่นใจ ปลอดภัย พร้อมเข้าเล่นได้ทันที 💸`;
  } else if (
    msg.includes('เล่นอะไรดี') ||
    msg.includes('เกมไหนดี') ||
    msg.includes('เกมไหนแตก') ||
    msg.includes('เกมไหนแจก')
  ) {
    reply =
`ถ้าชอบบวกง่าย ๆ แอดแนะนำแบบนี้เลยค่า:

⚽ บอล = บวกชัวร์ ถ้ารู้อยู่ข้างไหน
🎯 หวย = มีทุกวัน ลุ้นสนุก
🥊 มวย = แทงสดมันส์ ๆ
🃏 ป๊อกเด้ง = เล่นง่าย ได้ไว

ลองดูแนวนี้ก่อนก็ได้นะคะ โอกาสถอนสูงกว่าพวกหมุนเกมจ้าา`;
  } else if (isPhone) {
    reply = `ขอบคุณสำหรับเบอร์นะคะ 😊 เดี๋ยวแอดมินตรวจสอบแล้วจะรีบจัดการให้นะคะ`;
  } else {
    reply = isNight
      ? `ถ้าดึก ๆ แบบนี้แอดมินอาจตอบช้านิดนึงนะคะ 🥱 แต่สมัครเองได้เลยที่นี่จ้า 👇\n🔗 https://play.onedollar.bet/signup?ref=xtcqTA`
      : `หากสนใจสมัคร กดที่ลิงก์นี้ได้เลยนะคะ 👇\n🔗 https://play.onedollar.bet/signup?ref=xtcqTA\nหรือต้องการให้แอดมินสมัครให้ก็แจ้งข้อมูลเข้ามาได้เลยค่า 😊`;
  }

  return client.replyMessage(event.replyToken, {
    type: 'text',
    text: reply,
  });
}

app.get('/', (req, res) => {
  res.send('LINE Webhook Bot is running!');
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
